# 测试报告

## 环境

- 日期：2026-10-20（Asia/Hong_Kong）
- OS：Windows / PowerShell
- Node.js：v24.11.0（Vercel 当前默认大版本）与 v20.18.0 便携运行时；系统 PATH 未安装 Node/npm
- 浏览器：本机 Google Chrome，无头模式，1440×1200
- 数据模式：历史公开披露快照；无扶摇/iFinD/DeepSeek 密钥

## 实际执行

| 命令/检查 | 预期 | 实际结果 |
|---|---|---|
| `node scripts/check.js` | JS 可解析、关键 UI 节点存在 | 通过，23 个 JS 文件、5 个 UI 锚点 |
| `node scripts/vercel-check.js` | Vercel 路由、函数、静态输出、Node 版本、数据打包与超时配置一致 | 通过；4 个 Functions、`public` 输出、Node 24.x、`data/**`、20 秒上限 |
| `node scripts/test.js` | 规则、计算、DeepSeek 契约/降级、Schema、异常、命题裁决及 Vercel 请求契约通过 | Node 24 与 Node 20 均通过，49/49，失败 0，跳过 0 |
| `node scripts/build.js` | 生成独立生产包 | 通过，产物位于 `dist/` |
| 启动 `node server.js` | 监听 4173 | 通过 |
| `/api/analyze` | 返回 ResearchTask v2 | 通过；支持命题返回 8 条证据、1 条冲突 |
| `/api/health` | 返回快照和适配器状态 | 通过 |
| `/api/compare` | 返回 4 个同口径指标 | 通过 |
| `/api/followup` | 覆盖问题返回证据 ID | 通过，归因问题引用 O1/O2/S2/S3 |
| 异常模拟 | 映射状态且不当作反证 | 401/403/429/500/503/空数据/错误 Schema 全部通过 |
| Chrome 截图 | 页面可渲染、无静态白屏 | 通过，见 `artifacts/workspace.png` |
| 两个巨潮 PDF 链接 | HTTP 200 且为 PDF | 通过；文件大小约 1.95MB / 1.57MB |
| `dist/` 生产包启动 | 首页与核心 API 可用 | 通过；首页 200、health 200、analyze 返回 8 条证据/1 条冲突、compare 4 项、followup 引用 O1/O2/S2/S3 |
| 敏感信息扫描 | 不含密钥或硬编码凭证 | 通过；未发现 credential-like value |
| Node 24 本地 HTTP 回归 | 首页和四个 API 可用 | 通过；首页 200、health 为非实时快照、analyze 为 8 条证据/1 条冲突、compare 4 项、followup 引用 O1/O2/S2/S3 |
| Vercel 请求体边界 | 兼容平台解析后的对象/字符串并稳定报错 | 通过；字符串 JSON、畸形 JSON、非对象 JSON、超过 100KB、错误方法均覆盖 |
| Vercel CLI 本地构建尝试 | 用平台 CLI 继续验证配置 | CLI 64.5.0 在 Node 24 下启动，但因令牌无效在加载团队阶段终止；未构建、未部署、未做线上验证 |
| 回归 A：收入增速高于净利润增速 | 明确范围，不再澄清；直接比较并判错 | 通过；解析 `revenue, netProfit`，17.04% < 42.28%，并同时说明页面主营业务收入 18.07% 口径；结论“命题不成立” |
| 回归 B：利润全部由销量驱动 | 不以相关性替代排他性因果 | 通过；整体结论“证据不足，无法验证”，列出销量/售价、产品结构/成本和利润桥缺口；背景证据未进入整体支持 ID |
| 回归 C：明确普通同比命题 | 复用请求中的公司与期间，不重复澄清 | 通过；公司、期间来自研究范围，指标和关系来自命题，`missingFields=[]` |
| 回归 D：连续切换并保存任务 | 子问题、证据、结论和记录互不串用 | 通过；浏览器实际操作生成三个不同任务 ID；A/B 保存为两条独立记录，各自保留正确命题、结论和证据 ID |
| DeepSeek 无 Key | 不发起外部调用并明确降级 | 通过；`mode=rules_only`、`configured=false`、`fallbackUsed=true`，规则 A/B 结论不变 |
| DeepSeek 成功响应契约 | 服务端发出官方格式请求、校验语义/解释且不覆盖规则结论 | 通过（Mock 合同测试）；验证 URL、Bearer 头、模型、JSON mode、两阶段响应、证据 ID 与数值白名单；不等同真实账号联调 |
| DeepSeek 无效 Key / 超时 / 5xx / 非法 JSON | 明确错误、必要重试、规则降级 | 通过（受控响应）；401 不重试，超时/503 至多重试一次，错误不改变证据方向 |
| 复合方向命题 | 分别核验收入增长与扣非利润下降 | 通过；收入 17.04% 为支持子项，扣非利润 43.37% 反对“下降”，整体命题不成立 |
| 涨价驱动命题 | 缺少价格与利润桥时不得支持 | 通过；返回证据不足，背景利润增长不进入整体支持 |
| 缺失 `.env.example` 构建 | 不再出现 ENOENT | 通过；独立副本省略该文件，构建提示 optional skipped 并生成 manifest |
| Chrome 当前页面渲染 | 无 Key 时准确显示三类状态 | 通过；页面显示“规则模式 · DeepSeek 未配置”“非实时公开报告快照”“任务：当前浏览器”，截图为 `artifacts/deepseek-fallback.png` |
| Chrome Network 泄密检查 | 浏览器只调用同源后端，不带模型凭证 | 通过；DevTools Protocol 捕获 5 个请求，仅 `/`、静态资源与同源 `/api/analyze`；DeepSeek 外域请求 0，Authorization 请求头 0 |
| 最终 ZIP 解压回归 | 最新源码、文档与构建产物可复现 | 通过；独立目录再次执行 `npm run verify`，49/49、Vercel 检查和生产构建全部通过 |

## 用例覆盖

主链路覆盖命题输入、结构化任务、澄清、拆解、证据三分、结论、冲突、变化条件、比较、追问、保存/恢复逻辑与导出代码路径。金融计算覆盖正常同比、零/负基数、缺失值、百分点、累计期/单季度冲突、单位冲突和披露值不一致。合规覆盖未知公司不复用宁德时代证据、缺证不下确定结论、接口失败不当反证、追问证据外拒答、演示快照不冒充实时。

## 发现与修复

1. 系统 PATH 没有 Node/npm：使用官方 Node 24.11.0 与 20.18.0 便携运行时完成实际验证；交付不捆绑运行时。
2. Node 24 不再把 `node --test tests` 当作测试目录：新增跨版本测试启动脚本，显式枚举 `tests/*.test.js`。
3. API 首次加入 ResearchTask 时出现循环引用，导致 JSON 序列化 500：把任务内 analysis 改为深拷贝后复测通过。
4. 原 CSS 使用外部 Google Fonts，与严格 CSP 冲突：移除外部字体导入，保留系统字体回退。
5. README 曾保留过时的“公告摘要转录入口”描述：已改为当前实际使用的两条巨潮官方 PDF。
6. 原 `vercel.json` 使用 `runtime: nodejs20.x` 并把无扩展名 API 重写到 `.js`；按 Vercel 当前约定移除，改由 `api/` 自动路由及 `engines.node=24.x` 选择内置运行时。
7. Node 24 在当前 Windows 中文目录下使用 `fs.cpSync` 复制构建目录出现 `EIO`；改为逐文件递归复制后，Node 24/20 构建均通过。
8. Vercel CLI 64.5.0 读取到无效令牌，无法执行平台本地构建；该项如实保留为待授权线上验证，不以 `npm run build` 冒充。
9. 构建脚本强制读取 `.env.example`，部署上下文缺失时触发 ENOENT：改成可选复制，并在隔离副本删除该文件后完成实际构建。
10. 原模型适配器调用 OpenAI Responses API，且模型结果未进入规则前的结构流程：改为 DeepSeek Chat Completions 两阶段服务端编排，增加总时限、一次重试、JSON/字段/证据 ID/数字白名单校验与显式状态。
11. “扣非归母净利润”同时命中“归母净利润”，复合方向命题重复核验：修正最长口径去重，并逐子句验证增长/下降。

## 未覆盖与风险

未执行扶摇/iFinD 真实鉴权与限流、有效 DeepSeek Key 的在线调用、跨浏览器矩阵、Vercel 平台构建及本轮线上回归、真实 PDF 失效模拟、压测、安全红队和法律合规审查。DeepSeek 成功、错误和超时分支是 Mock 合同测试，不得描述为官方服务实际成功。任务仍为 localStorage，仅当前浏览器/设备可恢复；没有数据库或跨浏览器同步。
