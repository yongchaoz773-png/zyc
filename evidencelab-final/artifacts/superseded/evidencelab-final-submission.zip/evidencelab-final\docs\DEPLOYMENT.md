# GitHub 与 Vercel 发布步骤

## 当前审计结论

- 本地 Git 可用，交付仓库使用 `main` 分支。
- 系统没有 GitHub CLI，也没有检测到 GitHub Token，因此未创建远程仓库。
- Vercel CLI 37.14.0 可运行，但 `whoami` 明确返回无登录凭证，因此未部署。
- `npm run verify`、`dist/` 本地启动及核心 API 已通过；这不是线上部署验证。

## 创建 GitHub 仓库

1. 登录 <https://github.com/new>。
2. Repository name 填 `evidencelab`，Description 可填 `Traceable investment thesis verification workbench`。
3. 选择 `Public`。
4. 不勾选 Add a README、Add .gitignore、Choose a license，避免与本地提交冲突。
5. 点击 Create repository。
6. 在本项目目录执行 GitHub 页面显示的 HTTPS 命令，通常为：

```powershell
git remote add origin https://github.com/<你的用户名>/evidencelab.git
git push -u origin main
```

7. 打开真实仓库页面，确认 README、`api/`、`public/`、`tests/`、`docs/` 可见，且 `.env`、`dist/`、`.vercel/` 和 ZIP 不在仓库中。

## 通过 Vercel 网页部署

1. 登录 Vercel Dashboard，选择 Add New → Project。
2. 连接 GitHub 并导入 `evidencelab`。
3. Framework Preset 选择 `Other`。
4. Root Directory 保持 `./`。
5. Build Command 填 `npm run build`。
6. Output Directory 留空，不要填本地 `dist`；静态文件来自 `public/`，Serverless Functions 来自 `api/`。
7. 当前快照模式不需要环境变量。只有取得合法授权后，才在 Project Settings → Environment Variables 添加 `.env.example` 中的对应变量。
8. 点击 Deploy。

## 部署后验收

把 `<DEPLOYED_URL>` 替换为 Vercel 给出的真实 HTTPS 地址：

```powershell
curl.exe -I <DEPLOYED_URL>/
curl.exe <DEPLOYED_URL>/api/health
```

然后在浏览器实际验证：默认命题、支持/反对/无法验证切换、来源链接、冲突记录、跨期比较、追问、任务保存/恢复、503 异常演练、Markdown/JSON 导出和移动端布局。确认无误后，才把真实 GitHub URL 与 Web URL 写回 README 和提交清单；不要填写 localhost 或推测地址。
