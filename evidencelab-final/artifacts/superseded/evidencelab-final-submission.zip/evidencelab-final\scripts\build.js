'use strict';
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const dist = path.join(root, 'dist');
if (path.dirname(dist) !== root) throw new Error('Unsafe build target');
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });
for (const entry of ['api', 'data', 'lib', 'public', 'server.js', 'package.json', 'package-lock.json', 'vercel.json', '.env.example']) {
  fs.cpSync(path.join(root, entry), path.join(dist, entry), { recursive: true });
}
const manifest = { name: 'EvidenceLab', builtAt: new Date().toISOString(), node: process.version, mode: 'historical-public-snapshot' };
fs.writeFileSync(path.join(dist, 'build-manifest.json'), JSON.stringify(manifest, null, 2));
console.log(`Production bundle created: ${dist}`);
