# 测试报告

## 环境

- 日期：2026-10-19（Asia/Hong_Kong）
- OS：Windows / PowerShell
- Node.js：v20.18.0 便携运行时（系统 PATH 原先未安装 Node/npm）
- 浏览器：本机 Google Chrome，无头模式，1440×1200
- 数据模式：历史公开披露快照；无扶摇/iFinD/模型密钥

## 实际执行

| 命令/检查 | 预期 | 实际结果 |
|---|---|---|
| `node scripts/check.js` | JS 可解析、关键 UI 节点存在 | 通过，15 个 JS 文件、5 个 UI 锚点 |
| `node --test tests` | 规则、计算、Schema、异常测试通过 | 通过，26/26，失败 0，跳过 0 |
| `node scripts/build.js` | 生成独立生产包 | 通过，产物位于 `dist/` |
| 启动 `node server.js` | 监听 4173 | 通过 |
| `/api/analyze` | 返回 ResearchTask v2 | 通过；支持命题返回 8 条证据、1 条冲突 |
| `/api/health` | 返回快照和适配器状态 | 通过 |
| `/api/compare` | 返回 4 个同口径指标 | 通过 |
| `/api/followup` | 覆盖问题返回证据 ID | 通过，归因问题引用 O1/O2/S2/S3 |
| 异常模拟 | 映射状态且不当作反证 | 401/403/429/500/503/空数据/错误 Schema 全部通过 |
| Chrome 截图 | 页面可渲染、无静态白屏 | 通过，见 `artifacts/workspace.png` |
| 两个巨潮 PDF 链接 | HTTP 200 且为 PDF | 通过；文件大小约 1.95MB / 1.57MB |
| `dist/` 生产包启动 | 首页与核心 API 可用 | 通过；首页 200、health 200、analyze 返回 8 条证据/1 条冲突、compare 4 项、followup 引用 O1/O2/S2/S3 |
| 敏感信息扫描 | 不含密钥或硬编码凭证 | 通过；未发现 credential-like value |
| Vercel 凭证检查 | 判断能否部署 | CLI 37.14.0 可运行，但明确返回无登录凭证；未执行部署 |

## 用例覆盖

主链路覆盖命题输入、结构化任务、澄清、拆解、证据三分、结论、冲突、变化条件、比较、追问、保存/恢复逻辑与导出代码路径。金融计算覆盖正常同比、零/负基数、缺失值、百分点、累计期/单季度冲突、单位冲突和披露值不一致。合规覆盖未知公司不复用宁德时代证据、缺证不下确定结论、接口失败不当反证、追问证据外拒答、演示快照不冒充实时。

## 发现与修复

1. 系统 PATH 没有 Node/npm：下载官方 Node 20.18.0 便携运行时到系统临时目录完成实际验证；交付不捆绑运行时。
2. Windows 直接执行 `node --test tests/*.test.js` 不展开 glob：改为 `node --test tests`。
3. API 首次加入 ResearchTask 时出现循环引用，导致 JSON 序列化 500：把任务内 analysis 改为深拷贝后复测通过。
4. 原 CSS 使用外部 Google Fonts，与严格 CSP 冲突：移除外部字体导入，保留系统字体回退。
5. README 曾保留过时的“公告摘要转录入口”描述：已改为当前实际使用的两条巨潮官方 PDF。
6. 最新 Vercel CLI 对 Node 小版本要求高于本次便携运行时；改用兼容的 37.14.0 仅检查登录状态，结果为未授权。该 CLI 工具限制不影响项目自身 Node 18+ 构建。

## 未覆盖与风险

未执行扶摇/iFinD 真实鉴权与限流、可选模型在线调用、Playwright 自动点击流、跨浏览器矩阵、线上 Vercel 回归、真实 PDF 失效模拟、压测、安全红队和法律合规审查。浏览器端保存/导出主要通过代码检查和实际页面回归验证，未引入 Playwright 依赖；建议部署前补充。
